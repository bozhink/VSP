﻿//Copyright (C) Microsoft Corporation.  All rights reserved.

// Hello4.cs
using System;

public class Hello4
{
   public static int Main(string[] args)
   {
      Console.WriteLine("Hello, World!");
      return 0;
   }
}

