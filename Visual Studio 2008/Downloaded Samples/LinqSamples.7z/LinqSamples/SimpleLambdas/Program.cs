﻿//Copyright (C) Microsoft Corporation.  All rights reserved.

using System;
using System.Collections.Generic;
using System.Linq;

// See the ReadMe.html for additional information
class Program
{
    static void Main()
    {
        Samples.Sample1();        
        Console.ReadLine();
    }
}
